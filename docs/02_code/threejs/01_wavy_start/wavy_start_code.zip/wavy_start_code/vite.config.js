
export default {
    root: 'src/',
    publicDir: '../static/'
}